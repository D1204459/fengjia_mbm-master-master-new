import img1 from '@/assets/photo/carousel1.png'
import img2 from '@/assets/photo/carousel2.png'
import img3 from '@/assets/photo/carousel3.png'

export const carousel_img = [
    {
        id: 1,
        img: img1,
        text:''
    },
    {
        id: 2,
        img: img2,
        text:''
    },
    {
        id: 3,
        img: img3,
        text:''
    }
]