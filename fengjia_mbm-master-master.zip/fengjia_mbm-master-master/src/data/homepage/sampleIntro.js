export const intro = [
    {
        day: "周一～周日",
        time:"９：００～１７；３０",
        address: "407台中市西屯區福星路100號",
        img1: 'https://picsum.photos/900/600',
        img2: 'https://picsum.photos/900/600',
    }
]