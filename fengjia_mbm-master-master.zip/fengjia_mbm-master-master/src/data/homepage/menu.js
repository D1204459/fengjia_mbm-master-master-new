import img1 from '@/assets/photo/menu1.png'
import img2 from '@/assets/photo/menu2.png'
import img3 from '@/assets/photo/menu3.png'
import img4 from '@/assets/photo/menu4.png'
import img5 from '@/assets/photo/menu5.png'
import img6 from '@/assets/photo/menu6.png'
export const menu = [
    {
        name1: '場館導覽',
        photo1: img1,

        name2: '服務與售票',
        photo2: img2,

        name3: '表演活動',
        photo3: img3,

        name4: 'Q&A問答',
        photo4: img4,

        name5: '最新消息',
        photo5: img5,

        name6: '互動專區',
        photo6: img6,

    }
]