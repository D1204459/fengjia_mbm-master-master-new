<script setup>
import b_header from '@/components/b_header.vue'


window.scrollTo(0,0);

</script>

<template>

<router-view></router-view>

</template>

<style scoped>

</style>
